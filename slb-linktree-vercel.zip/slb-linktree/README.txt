SLB HIDROMECÂNICA — MINI-SITE DE LINKS

CONTEÚDO
index.html = página completa em HTML/CSS/JavaScript
logo.png = logotipo enviado, recortado para reduzir margens brancas

PUBLICAR NA VERCEL
1. Descompacte o ZIP.
2. Abra index.html e procure por: const SITE_OFICIAL = '';
3. Coloque o endereço completo entre as aspas, como https://seudominio.com.br
4. Publique a pasta como um projeto estático na Vercel, via GitHub ou Vercel CLI.
   Pelo terminal, dentro da pasta, rode: npx vercel --prod
5. Na Vercel, o framework deve ser Other e o diretório de saída não precisa ser definido.

CONTATOS COPIADOS DO HTML ORIGINAL
Comercial: Mattheus — 554235224313
Financeiro: Josiane — 5542933001910

OBS.: O HTML original não contém o URL público do site; por isso o link do site ainda depende de preenchimento.
